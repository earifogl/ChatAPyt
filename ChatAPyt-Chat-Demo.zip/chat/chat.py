print ("Welcome aboard!")
name = raw_input("Username:")
print name, "has joined the chat!"
message = raw_input ("Say something")
print "[",name,"]", message
number = 1
if message == ("fuck"):
  print name, "has got", number, "warning"
  number2 = 1
else:
  number2 = 0

message = raw_input ("Say something")
print "[",name,"]", message
if message == ("fuck"):
  print name, "has got", number2 + 1, "warning"
  

 